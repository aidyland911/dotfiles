print current to standard output (default)

The {{aka}} command prints the current time setting with the emoji. It is designed to be called repeatedly from the command line or applications like {{cmd "tmux"}}.
