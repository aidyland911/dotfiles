start the current pomo timer

The {{aka}} command starts a pomo timer with an optional new `DURATION`. The special `hour` parameter can be passed to calculate the duration to the beginning of the next hour.

Note that if `autoreset` is set there is no need to restart the timer.

