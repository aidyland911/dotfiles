stop the current pomo timer

The {{aka}} command simply stops the timer so that any subsequent calls to {{cmd "print"}} (the default) simply return without printing anything.
