package main

import (
	"github.com/rwxrob/pomo"
)

func main() {
	pomo.Cmd.Run()
}
